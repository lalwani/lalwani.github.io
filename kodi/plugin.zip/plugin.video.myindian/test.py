import net

n=net.Net()
r=n.http_GET(url="https://www.ohidur.com").content


